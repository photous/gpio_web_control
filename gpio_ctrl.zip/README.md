# gpio_web_control
A web interface created with Python and Flask micro-framework in order to control GPIO pins in Raspberry Pi
